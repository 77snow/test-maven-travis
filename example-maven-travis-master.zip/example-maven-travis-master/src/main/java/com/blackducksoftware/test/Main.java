package com.blackducksoftware.test;

import java.util.Arrays;

/**
 * Demo class showing compilation of repository source
 *
 * @author romeara
 * @since 0.1
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("Hello Arguments! (" + Arrays.toString(args) + ")");
    }

}
